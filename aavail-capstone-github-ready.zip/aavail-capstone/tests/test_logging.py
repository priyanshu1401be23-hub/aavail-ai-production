import json
from src.monitoring import log_prediction, read_prediction_logs

def test_prediction_logging(tmp_path, monkeypatch):
    import src.monitoring as monitoring
    path = tmp_path / "predictions.jsonl"
    monkeypatch.setattr(monitoring, "LOG_PATH", path)
    record = monitoring.log_prediction(
        "test-id", {"age": 22}, 1, 0.91
    )
    rows = monitoring.read_prediction_logs(path)
    assert record["request_id"] == "test-id"
    assert len(rows) == 1
    assert rows[0]["prediction"] == 1
