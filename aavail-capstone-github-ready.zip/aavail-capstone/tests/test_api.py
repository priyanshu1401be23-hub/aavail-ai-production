import pandas as pd
from src.app import create_app

class FakeModel:
    def predict(self, frame):
        return [1]
    def predict_proba(self, frame):
        return [[0.2, 0.8]]

def test_health_reports_model_loaded():
    client = create_app(FakeModel()).test_client()
    response = client.get("/health")
    assert response.status_code == 200
    assert response.get_json()["model_loaded"] is True

def test_predict_returns_prediction():
    client = create_app(FakeModel()).test_client()
    payload = {
        "country_name": "united_states", "age": 29,
        "subscriber_type": "aavail_basic", "num_streams": 18
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    assert response.get_json()["is_subscriber_prediction"] == 1

def test_predict_rejects_missing_features():
    client = create_app(FakeModel()).test_client()
    response = client.post("/predict", json={"age": 29})
    assert response.status_code == 400
    assert "missing" in response.get_json()
