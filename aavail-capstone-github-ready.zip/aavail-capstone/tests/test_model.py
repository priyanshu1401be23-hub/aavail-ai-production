import pandas as pd
from src.train import build_pipeline
from sklearn.linear_model import LogisticRegression

def test_model_pipeline_fits_and_predicts():
    X = pd.DataFrame({
        "country_name": ["united_states", "singapore", "united_states", "singapore"],
        "age": [20, 30, 25, 40],
        "subscriber_type": ["aavail_basic", "aavail_premium", "aavail_basic", "aavail_unlimited"],
        "num_streams": [20, 8, 18, 5]
    })
    y = [1, 0, 1, 0]
    model = build_pipeline(LogisticRegression(max_iter=200))
    model.fit(X, y)
    assert len(model.predict(X)) == 4
