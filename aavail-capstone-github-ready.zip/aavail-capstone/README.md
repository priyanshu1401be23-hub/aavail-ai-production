# AAVAIL Subscription Status Classification API

A reproducible capstone repository for analyzing the AAVAIL customer dataset, comparing classification models, and serving subscription-status predictions through a Flask API.

## Business objective
Help AAVAIL teams segment customer records by their **recorded subscription status** across the United States and Singapore. The model estimates whether a record is currently marked as subscribed (`is_subscriber=True`) from country, age, subscriber plan type, and stream count.

**Scope limitation:** the supplied file is already imputed and contains no event date or longitudinal history. Therefore this repository does not claim to forecast future churn or prove causal churn drivers. `is_subscriber=False` is treated as not currently subscribed, not as a future churn event.

## Dataset
`data/aavail_imputed.csv` is the available imputed dataset. Expected columns include `customer_id`, `country_name`, `age`, `customer_name`, `is_subscriber`, `subscriber_type`, and `num_streams`. Personal identifiers are not used as model features.

## Reproduce
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m src.eda
python -m src.train
pytest -q
python -m src.app
```
Open `http://localhost:5000/health`.

## API
`POST /predict`
```json
{
  "country_name": "united_states",
  "age": 29,
  "subscriber_type": "aavail_basic",
  "num_streams": 18
}
```
Returns a prediction, estimated probability, and request ID. Each prediction is written as one JSON line to `logs/predictions.jsonl`.

`GET /health` reports service and model availability.

## Docker
```bash
docker compose up --build
```

## Testing and CI
- API tests: health, valid prediction, missing-field validation.
- Model test: preprocessing and estimator pipeline fit/predict.
- Logging test: JSONL persistence.
- GitHub Actions runs training and tests on pushes and pull requests.

## Monitoring
Prediction requests are timestamped and logged with request ID, feature payload, predicted class, and probability. Logs support volume and output review. This is an initial operational monitor, not a substitute for labeled-outcome performance monitoring or a statistical drift detector. A production extension should join delayed ground-truth labels and track precision, recall, calibration, and feature drift over time.

## Model comparison
Training compares a majority-class `DummyClassifier` baseline, balanced logistic regression, and balanced random forest using a stratified holdout split. The selected non-baseline model is saved to `artifacts/subscription_model.joblib`; metrics are saved to `artifacts/metrics.json`. Re-run training to reproduce results.

## Repository map
- `src/ingest.py`: dataset validation and loading
- `src/eda.py`: missingness and market comparison charts
- `src/train.py`: preprocessing, baseline/model comparison, evaluation, model export
- `src/app.py`: Flask API
- `src/monitoring.py`: structured prediction logging
- `tests/`: API, model, and logging tests
- `Dockerfile`, `docker-compose.yml`: container deployment
- `.github/workflows/tests.yml`: CI test workflow

## Peer-review checklist
1. API unit tests: `tests/test_api.py`
2. Model unit tests: `tests/test_model.py`
3. Logging unit tests: `tests/test_logging.py`
4. Single test command: `pytest -q`
5. Performance monitoring: timestamped prediction logs; add labeled feedback for true ongoing model metrics
6. Read/write isolation: model artifact is loaded at startup; prediction logs are separate from model artifacts and source data
7. API behavior: `/health` and `/predict`, including validation
8. Data ingestion: `src/ingest.py`
9. Multiple models compared: dummy baseline, logistic regression, random forest
10. EDA visualizations: `python -m src.eda`
11. Containerization: Dockerfile and Compose configuration

## Important before publishing
The dataset in this repository is the imputed CSV found in the working project files. If your course solution requires the original raw data or a specific previously trained capstone model, add those original files before claiming exact reproduction. Do not commit confidential or personally identifying data to a public repository unless permitted by the course.
