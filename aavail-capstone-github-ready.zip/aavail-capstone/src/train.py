import json
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from src.config import DATA_PATH, MODEL_PATH, METRICS_PATH, FEATURES, TARGET
from src.ingest import load_data

NUMERIC = ["age", "num_streams"]
CATEGORICAL = ["country_name", "subscriber_type"]

def build_pipeline(estimator):
    numeric = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
    categorical = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encode", OneHotEncoder(handle_unknown="ignore"))
    ])
    prep = ColumnTransformer([
        ("numeric", numeric, NUMERIC),
        ("categorical", categorical, CATEGORICAL)
    ])
    return Pipeline([("preprocess", prep), ("model", estimator)])

def train():
    df = load_data(DATA_PATH)
    df = df.dropna(subset=[TARGET])
    X, y = df[FEATURES], df[TARGET].astype(int)
    if y.nunique() < 2:
        raise ValueError("Training requires both target classes.")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    candidates = {
        "dummy_baseline": build_pipeline(DummyClassifier(strategy="most_frequent")),
        "logistic_regression": build_pipeline(LogisticRegression(max_iter=1000, class_weight="balanced")),
        "random_forest": build_pipeline(RandomForestClassifier(
            n_estimators=300, min_samples_leaf=3, random_state=42, class_weight="balanced"
        ))
    }
    results = {}
    fitted = {}
    for name, model in candidates.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        prob = model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") else pred
        results[name] = {
            "accuracy": round(float(accuracy_score(y_test, pred)), 4),
            "precision": round(float(precision_score(y_test, pred, zero_division=0)), 4),
            "recall": round(float(recall_score(y_test, pred, zero_division=0)), 4),
            "f1": round(float(f1_score(y_test, pred, zero_division=0)), 4),
            "roc_auc": round(float(roc_auc_score(y_test, prob)), 4) if y_test.nunique() == 2 else None
        }
        fitted[name] = model
    winner = max(
        ["logistic_regression", "random_forest"],
        key=lambda name: results[name]["f1"]
    )
    MODEL_PATH.parent.mkdir(exist_ok=True)
    METRICS_PATH.parent.mkdir(exist_ok=True)
    joblib.dump(fitted[winner], MODEL_PATH)
    payload = {
        "target": TARGET,
        "features": FEATURES,
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "selected_model": winner,
        "models": results,
        "data_note": "Cross-sectional imputed dataset; this predicts recorded subscription status, not future churn."
    }
    METRICS_PATH.write_text(json.dumps(payload, indent=2))
    print(json.dumps(payload, indent=2))
    return payload

if __name__ == "__main__":
    train()
