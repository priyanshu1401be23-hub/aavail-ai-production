from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "aavail_imputed.csv"
MODEL_PATH = ROOT / "artifacts" / "subscription_model.joblib"
METRICS_PATH = ROOT / "artifacts" / "metrics.json"
LOG_PATH = ROOT / "logs" / "predictions.jsonl"

TARGET = "is_subscriber"
FEATURES = ["country_name", "age", "subscriber_type", "num_streams"]
