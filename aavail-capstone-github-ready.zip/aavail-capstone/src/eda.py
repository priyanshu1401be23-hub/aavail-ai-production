import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from src.config import DATA_PATH, TARGET
from src.ingest import load_data

def generate():
    df = load_data(DATA_PATH)
    out = DATA_PATH.parent.parent / "artifacts"
    out.mkdir(exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    missing = df.isna().sum()
    missing = missing[missing > 0]
    if len(missing):
        axes[0].bar(missing.index.astype(str), missing.values)
        axes[0].tick_params(axis="x", rotation=45)
    else:
        axes[0].text(0.5, 0.5, "No missing values in supplied imputed file", ha="center", va="center")
    axes[0].set_title("Missing values by column")
    axes[0].set_ylabel("Missing rows")
    rates = df.groupby("country_name")[TARGET].mean().sort_values()
    axes[1].bar(rates.index.astype(str), rates.values)
    axes[1].set_title("Observed subscriber share by market")
    axes[1].set_ylabel("Subscriber share")
    axes[1].set_ylim(0, 1)
    fig.tight_layout()
    fig.savefig(out / "eda_missingness_and_market.png", dpi=160)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4))
    tab = pd.crosstab(df["country_name"], df[TARGET], normalize="index")
    tab.plot(kind="bar", stacked=True, ax=ax, title="Subscription status by market")
    ax.set_ylabel("Share of customers")
    fig.tight_layout()
    fig.savefig(out / "subscription_status_by_market.png", dpi=160)
    plt.close(fig)
    print("EDA charts saved to artifacts/")
if __name__ == "__main__":
    generate()
