import json
from datetime import datetime, timezone
from src.config import LOG_PATH

def log_prediction(request_id, features, prediction, probability):
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "request_id": request_id,
        "features": features,
        "prediction": int(prediction),
        "probability_subscribed": float(probability)
    }
    with LOG_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record) + "\n")
    return record

def read_prediction_logs(path=LOG_PATH):
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows
