import uuid
import joblib
import pandas as pd
from flask import Flask, jsonify, request
from src.config import MODEL_PATH, FEATURES
from src.monitoring import log_prediction

def create_app(model=None):
    app = Flask(__name__)
    predictor = model
    if predictor is None and MODEL_PATH.exists():
        predictor = joblib.load(MODEL_PATH)

    @app.get("/health")
    def health():
        return jsonify({"status": "ok", "model_loaded": predictor is not None})

    @app.post("/predict")
    def predict():
        if predictor is None:
            return jsonify({"error": "Model is not trained. Run python -m src.train first."}), 503
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            return jsonify({"error": "Request body must be a JSON object."}), 400
        missing = [key for key in FEATURES if key not in body]
        if missing:
            return jsonify({"error": "Missing required features.", "missing": missing}), 400
        try:
            row = {key: body[key] for key in FEATURES}
            if not isinstance(row["age"], (int, float)) or not isinstance(row["num_streams"], (int, float)):
                raise ValueError("age and num_streams must be numeric")
            frame = pd.DataFrame([row], columns=FEATURES)
            prediction = int(predictor.predict(frame)[0])
            probability = float(predictor.predict_proba(frame)[0][1])
            request_id = str(uuid.uuid4())
            log_prediction(request_id, row, prediction, probability)
            return jsonify({
                "request_id": request_id,
                "is_subscriber_prediction": prediction,
                "probability_subscribed": round(probability, 6),
                "interpretation": "currently_subscribed" if prediction == 1 else "not_currently_subscribed"
            })
        except (ValueError, TypeError) as exc:
            return jsonify({"error": str(exc)}), 400

    return app

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
