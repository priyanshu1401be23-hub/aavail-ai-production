import pandas as pd
from src.config import DATA_PATH

REQUIRED_COLUMNS = {
    "country_name", "age", "is_subscriber", "subscriber_type", "num_streams"
}

def load_data(path=DATA_PATH):
    df = pd.read_csv(path)
    missing = REQUIRED_COLUMNS.difference(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    df = df.copy()
    df["is_subscriber"] = df["is_subscriber"].map(
        lambda value: value if isinstance(value, bool) else
        str(value).strip().lower() in {"true", "1", "yes"}
    )
    return df
